package com.example.calculator

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.sqrt

class MainActivity : AppCompatActivity() {
    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val editFirst = findViewById<TextView>(R.id.editFirst)
        val editSecond = findViewById<TextView>(R.id.editSecond)
        val addition = findViewById<Button>(R.id.Addition)
        val subtract = findViewById<Button>(R.id.subtract)
        val multiply = findViewById<Button>(R.id.multiply)
        val divide = findViewById<Button>(R.id.divide)
        val displayOperation = findViewById<TextView>(R.id.calculation)
        val square = findViewById<Button>(R.id.square)
        val power = findViewById<Button>(R.id.power)

        addition?.setOnClickListener {

            val num1 = editFirst.text.toString().toInt()
            val num2 = editSecond.text.toString().toInt()
            val calc = num1 + num2
            displayOperation.text = "$num1 + $num2 = $calc"

        }
        subtract?.setOnClickListener {

            val num1 = editFirst.text.toString().toInt()
            val num2 = editSecond.text.toString().toInt()
            val calc = num1 - num2
            displayOperation.text = "$num1 - $num2 = $calc"

        }
        multiply?.setOnClickListener {

            val num1 = editFirst.text.toString().toInt()
            val num2 = editSecond.text.toString().toInt()
            val calc = num1 * num2
            displayOperation.text = "$num1 * $num2 = $calc"

        }
        divide?.setOnClickListener {

            val num1 = editFirst.text.toString().toInt()
            val num2 = editSecond.text.toString().toInt()
            val calc : Double
            if (num2 == 0){
                displayOperation.text = "$num1 is not divisible by $num2"
                }else {
                    calc = (num1 / num2).toDouble()
                    displayOperation.text = "$num1 / $num2 = $calc"
                }


        }
        square?.setOnClickListener {
            val num1 = editFirst.text.toString().toInt()
            val num2 = editSecond.text.toString().toInt()
            val calc : Double = sqrt(num1.toDouble())
            val altCalc : Double = sqrt(num2.toDouble())
            if (num1 <= 0 || num2 <= 0) {
                displayOperation.text = "sqrt($num1) = $calc\nsqrt($num2) = $altCalc i"
            } else {
                displayOperation.text = "sqrt($num1) = $calc\nsqrt($num2) = $altCalc"
            }
        }

        power?.setOnClickListener {

            val base = editFirst.text.toString().toInt()
            var exponent = editSecond.text.toString().toInt()
            val index = exponent
            var calc: Long = 1
                while (index !=0) {
                    calc *= base.toLong()
                    --exponent
                }
            displayOperation.text = "$base ^ $exponent = $calc"
        }
    }
}
